package com.mycompany.lojainformatica.DAO;

import com.example.model.Computador;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ComputadorDAO {
    
        static String URL = "jdbc:mysql://localhost:3306/lojainformatica";
        static String login = "root";
        static String senha = "080394";
               
    
    public static boolean salvar(Computador obj){
        
            Connection conexao = null;
            boolean retorno = false;
            
        try {
            
            //1- Load driver mysql:
            Class.forName("com.mysql.cj.jdbc.Driver");
            
             //2- Fazer conexao com banco:
            conexao = DriverManager.getConnection(URL, login, senha);
            
            //3- Preparar comando SQL:
            PreparedStatement instrucaoSQL = conexao.prepareStatement(
                "INSERT INTO computador (marca, hd, processador) VALUES (?, ?, ?);"
            );

            
            instrucaoSQL.setString(1, obj.getMarca());
            instrucaoSQL.setString(2, obj.getHd());
            instrucaoSQL.setString(3, obj.getProcessador());
            
            //4 - Executar o comando:
            int linhasAfetadas = instrucaoSQL.executeUpdate();
            
            if(linhasAfetadas>0){
                retorno = true;
            }                 
           
            
        }catch (ClassNotFoundException e){
                    System.out.println("Driver não encontrado");
            
        } catch (Exception e) {
                    System.out.println(e.getMessage());
                    
        } finally {
            if(conexao != null){
                try {
                    conexao.close();
                } catch (SQLException ex) {
                    Logger.getLogger(ComputadorDAO.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
                
        }           
        return retorno;    
    }
    
    public static ArrayList<Computador> listar(){
 ArrayList<Computador> listaRetorno = new ArrayList<>();
    Connection conexao = null;
    ResultSet rs = null;
    PreparedStatement instrucaoSQL = null;

    try {
        // 1- Load driver mysql:
        Class.forName("com.mysql.cj.jdbc.Driver");

        // 2- Fazer conexao com banco:
        conexao = DriverManager.getConnection(URL, login, senha);

        // 3- Preparar comando SQL:
        instrucaoSQL = conexao.prepareStatement("SELECT * FROM computador");

        // 4- Executar o comando:
        rs = instrucaoSQL.executeQuery();

        if (rs != null) {
            while (rs.next()) {
                int id = rs.getInt("Id");
                String marca = rs.getString("marca");
                String hd = rs.getString("hd");
                String processador = rs.getString("processador");

                Computador item = new Computador(marca);
                item.setId(id);
                listaRetorno.add(item);
            }
        }

    } catch (Exception e) {
        e.printStackTrace(); // Log do erro para debug
        listaRetorno = new ArrayList<>(); // Inicializa a lista para evitar NullPointerException

    } finally {
        // Fechar ResultSet
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException ex) {
                Logger.getLogger(ComputadorDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        // Fechar PreparedStatement
        if (instrucaoSQL != null) {
            try {
                instrucaoSQL.close();
            } catch (SQLException ex) {
                Logger.getLogger(ComputadorDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        // Fechar Connection
        if (conexao != null) {
            try {
                conexao.close();
            } catch (SQLException ex) {
                Logger.getLogger(ComputadorDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    return listaRetorno;
}
public static boolean alterar(Computador obj) {
        Connection conexao = null;
        boolean retorno = false;

        try {
            // 1- Load driver mysql:
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2- Fazer conexão com banco:
            conexao = DriverManager.getConnection(URL, login, senha);

            // 3- Preparar comando SQL:
            PreparedStatement instrucaoSQL = conexao.prepareStatement(
                "UPDATE computador SET marca = ?, hd = ?, processador = ?;"
            );

            // Configurar os parâmetros da instrução SQL
            instrucaoSQL.setString(1, obj.getMarca());
            instrucaoSQL.setString(2, obj.getHd());
            instrucaoSQL.setString(3, obj.getProcessador());
            //instrucaoSQL.setInt(4, obj.getId());

            // 4 - Executar o comando:
            int linhasAfetadas = instrucaoSQL.executeUpdate();

            if (linhasAfetadas > 0) {
                retorno = true;
                System.out.println("Atualização bem-sucedida. Linhas afetadas: " + linhasAfetadas);
            } else {
                System.out.println("Nenhuma linha afetada pela atualização.");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("Driver não encontrado: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Erro SQL: " + e.getMessage());
        } finally {
            if (conexao != null) {
                try {
                    conexao.close();
                } catch (SQLException ex) {
                    System.out.println("Erro ao fechar conexão: " + ex.getMessage());
            }
        }
    }
    
    return retorno;
}

public static boolean excluir(Computador computador) {
    Connection conexao = null;
    boolean retorno = false;

    try {
        // 1- Carregar o driver do MySQL:
        Class.forName("com.mysql.cj.jdbc.Driver");

        // 2- Estabelecer conexão com o banco de dados:
        conexao = DriverManager.getConnection(URL, login, senha);

        // 3- Preparar o comando SQL:
        PreparedStatement instrucaoSQL = conexao.prepareStatement(
            "DELETE FROM computador WHERE marca = ?;"
        );

        // Configurar os parâmetros da instrução SQL
        instrucaoSQL.setString(1, computador.getMarca());

        // 4 - Executar o comando:
        int linhasAfetadas = instrucaoSQL.executeUpdate();

        if (linhasAfetadas > 0) {
            retorno = true;
            System.out.println("Exclusão bem-sucedida: " + linhasAfetadas);
        } else {
            System.out.println("Nenhum registro foi excluído.");
        }
    } catch (ClassNotFoundException e) {
        System.out.println("Driver não encontrado: " + e.getMessage());
    } catch (SQLException e) {
        System.out.println("Erro SQL: " + e.getMessage());
    } finally {
        if (conexao != null) {
            try {
                conexao.close();
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar conexão: " + ex.getMessage());
            }
        }
    }

    return retorno;
}

}