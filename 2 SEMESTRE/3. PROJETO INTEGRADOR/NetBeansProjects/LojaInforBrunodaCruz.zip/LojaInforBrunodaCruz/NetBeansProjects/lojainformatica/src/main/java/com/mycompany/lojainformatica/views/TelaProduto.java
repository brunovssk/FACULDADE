package com.mycompany.lojainformatica.views;



import com.mycompany.lojainformatica.DAO.ComputadorDAO;
import javax.swing.JOptionPane;
import com.example.model.Computador;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.table.DefaultTableModel;

public class TelaProduto extends javax.swing.JFrame {
    
    Computador objAlterar = null;

    public TelaProduto() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        telaProduto = new javax.swing.JTabbedPane();
        pnlCadastrar = new javax.swing.JPanel();
        lblHD = new javax.swing.JLabel();
        lblProcessador = new javax.swing.JLabel();
        lblMarca = new javax.swing.JLabel();
        txtHD = new javax.swing.JTextField();
        txtProcessador = new javax.swing.JTextField();
        txtMarca = new javax.swing.JTextField();
        btnCancelarCadastro = new javax.swing.JButton();
        btnConfirmarCadastro = new javax.swing.JButton();
        lblId = new javax.swing.JLabel();
        lblIdProduto = new javax.swing.JLabel();
        pnlConsultar = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblProduto = new javax.swing.JTable();
        lblConsultarMarca = new javax.swing.JLabel();
        txtCampoConsultarMarca = new javax.swing.JTextField();
        btnPesquisarProduto = new javax.swing.JButton();
        btnAlterarProduto = new javax.swing.JButton();
        btnAdicionarProduto = new javax.swing.JButton();
        btnExcluirProduto = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblHD.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblHD.setText("HD:");

        lblProcessador.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblProcessador.setText("Processador:");

        lblMarca.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblMarca.setText("Marca:");

        txtMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMarcaActionPerformed(evt);
            }
        });

        btnCancelarCadastro.setText("CANCELAR");
        btnCancelarCadastro.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnConfirmarCadastro.setText("CONFIRMAR");
        btnConfirmarCadastro.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnConfirmarCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarCadastroActionPerformed(evt);
            }
        });

        lblId.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblId.setText("ID:");

        javax.swing.GroupLayout pnlCadastrarLayout = new javax.swing.GroupLayout(pnlCadastrar);
        pnlCadastrar.setLayout(pnlCadastrarLayout);
        pnlCadastrarLayout.setHorizontalGroup(
            pnlCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCadastrarLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCadastrarLayout.createSequentialGroup()
                        .addComponent(lblId, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblIdProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(pnlCadastrarLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(btnConfirmarCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 106, Short.MAX_VALUE)
                        .addComponent(btnCancelarCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlCadastrarLayout.createSequentialGroup()
                        .addGroup(pnlCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblProcessador, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblMarca, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblHD, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtMarca)
                            .addComponent(txtHD)
                            .addComponent(txtProcessador))))
                .addGap(21, 21, 21))
        );
        pnlCadastrarLayout.setVerticalGroup(
            pnlCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCadastrarLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlCadastrarLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(lblIdProduto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(lblId, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblHD, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtHD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblProcessador, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtProcessador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(pnlCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConfirmarCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancelarCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37))
        );

        telaProduto.addTab("Cadastrar", pnlCadastrar);

        tblProduto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Marca", "HD", "Processador"
            }
        ));
        jScrollPane1.setViewportView(tblProduto);

        lblConsultarMarca.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblConsultarMarca.setText("Marca:");

        txtCampoConsultarMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCampoConsultarMarcaActionPerformed(evt);
            }
        });

        btnPesquisarProduto.setText("Pesquisar");
        btnPesquisarProduto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnPesquisarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarProdutoActionPerformed(evt);
            }
        });

        btnAlterarProduto.setText("Alterar");
        btnAlterarProduto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAlterarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarProdutoActionPerformed(evt);
            }
        });

        btnAdicionarProduto.setText("Adicionar");
        btnAdicionarProduto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAdicionarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarProdutoActionPerformed(evt);
            }
        });

        btnExcluirProduto.setText("EXCLUIR");
        btnExcluirProduto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnExcluirProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirProdutoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlConsultarLayout = new javax.swing.GroupLayout(pnlConsultar);
        pnlConsultar.setLayout(pnlConsultarLayout);
        pnlConsultarLayout.setHorizontalGroup(
            pnlConsultarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlConsultarLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlConsultarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlConsultarLayout.createSequentialGroup()
                        .addComponent(lblConsultarMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCampoConsultarMarca))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(pnlConsultarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnPesquisarProduto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
                    .addComponent(btnAlterarProduto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAdicionarProduto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnExcluirProduto))
                .addContainerGap())
        );

        pnlConsultarLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnAdicionarProduto, btnAlterarProduto, btnExcluirProduto, btnPesquisarProduto});

        pnlConsultarLayout.setVerticalGroup(
            pnlConsultarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlConsultarLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlConsultarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlConsultarLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnPesquisarProduto))
                    .addGroup(pnlConsultarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblConsultarMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtCampoConsultarMarca)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlConsultarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlConsultarLayout.createSequentialGroup()
                        .addComponent(btnAlterarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnAdicionarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnExcluirProduto))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(83, 83, 83))
        );

        pnlConsultarLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnAdicionarProduto, btnAlterarProduto, btnExcluirProduto, btnPesquisarProduto});

        telaProduto.addTab("Consultar", pnlConsultar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(telaProduto)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(telaProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnExcluirProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirProdutoActionPerformed
       
    int linhaSelecionada = tblProduto.getSelectedRow();

    if (linhaSelecionada >= 0) {
        // Recuperar o modelo da tabela
        DefaultTableModel modeloTabela = (DefaultTableModel) tblProduto.getModel();
        // Recuperar o objeto Computador correspondente à linha selecionada
        String marca = (String) modeloTabela.getValueAt(linhaSelecionada, 1);
        Computador computador = new Computador(marca);
        // Chamar o método excluir da classe ComputadorDAO
        boolean exclusaoSucesso = ComputadorDAO.excluir(computador); 

        if (exclusaoSucesso) {
            JOptionPane.showMessageDialog(rootPane, "Computador excluído com sucesso.");
                      
        } else {
            JOptionPane.showMessageDialog(rootPane, "Falha ao excluir o computador.");
        }
    }  
    }//GEN-LAST:event_btnExcluirProdutoActionPerformed

    public void atualizarTabela(){
    
    }
    
    private void txtCampoConsultarMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCampoConsultarMarcaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCampoConsultarMarcaActionPerformed

    private void btnConfirmarCadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarCadastroActionPerformed
       
        //Se tiver alteração
        if(objAlterar!= null){
            //modo alteração:
            
            //resgatar dados alterados:
            String marca = txtMarca.getText();
            String hd = txtHD.getText();
            String processador = txtProcessador.getText();
            
            objAlterar.setMarca(marca);
            objAlterar.setHd(hd);
            objAlterar.setProcessador(processador);
            
            //TODO Chamar DAO para alterar:
            boolean retornoAlteracao = ComputadorDAO.alterar(objAlterar);
            if(retornoAlteracao){
                JOptionPane.showMessageDialog(rootPane, "Sucesso ao Alterar");    
                
                //Limpar campos da tela de cadastro:
                objAlterar = null;
                txtMarca.setText("");
                txtHD.setText("");
                txtProcessador.setText("");
                //lblIdProduto.setText("");
                
            }else {
                JOptionPane.showMessageDialog(rootPane, "Falha ao Alterar");
            
            }
               
        
        }else{
        //Modo de inclusão:
        //1- Passando dados de interface para obj
            String marca = txtMarca.getText();
            String hd = txtHD.getText();
            String processador = txtProcessador.getText();

            Computador objCadastrar = new Computador(marca);

            //2- TODO passa obj para banco de dados
            boolean retornoBanco = ComputadorDAO.salvar(objCadastrar);

            if(retornoBanco){
                JOptionPane.showMessageDialog(rootPane, 
                                    "Produto cadastrado com sucesso!");
            }else{            
                JOptionPane.showMessageDialog(rootPane, 
                                     "Falha ao cadastrar o produto");
        }
        
       }               
    }//GEN-LAST:event_btnConfirmarCadastroActionPerformed

    private void txtMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMarcaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMarcaActionPerformed

    private void btnPesquisarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarProdutoActionPerformed
        // TODO add your handling code here:
       ArrayList<Computador> lista = ComputadorDAO.listar();

       DefaultTableModel modeloTabela = (DefaultTableModel)tblProduto.getModel();
       
       modeloTabela.setRowCount(0);
               
        for (Computador computador : lista) {
            modeloTabela.addRow(new String[]{String.valueOf(computador.getId()), 
            computador.getMarca(), 
            computador.getHd(), 
            computador.getProcessador()});
}   
              
        
    }//GEN-LAST:event_btnPesquisarProdutoActionPerformed

    private void btnAdicionarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdicionarProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAdicionarProdutoActionPerformed

    private void btnAlterarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarProdutoActionPerformed
       
        DefaultTableModel modeloTabela = (DefaultTableModel) tblProduto.getModel();
        int linhaSelecionada = tblProduto.getSelectedRow();
        
        if(linhaSelecionada >= 0){
            
            int id = Integer.parseInt(modeloTabela.getValueAt(linhaSelecionada, 0).toString());
            String marca = modeloTabela.getValueAt(linhaSelecionada, 1).toString();
            String hd = modeloTabela.getValueAt(linhaSelecionada, 2).toString();
            String processador = modeloTabela.getValueAt(linhaSelecionada, 3).toString();
            
            objAlterar = new Computador(marca);
            
            //Redireciona para a tela de cadastro:
            telaProduto.setSelectedIndex(0);
            
            lblIdProduto.setText(String.valueOf(objAlterar.getId()));
            txtMarca.setText(objAlterar.getMarca());
            txtHD.setText(objAlterar.getHd());
            txtProcessador.setText(objAlterar.getProcessador());
            
            
        
        }else{
            JOptionPane.showMessageDialog(rootPane, "Selecione uma linha da tabela! ");
        }
    }//GEN-LAST:event_btnAlterarProdutoActionPerformed


    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaProduto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdicionarProduto;
    private javax.swing.JButton btnAlterarProduto;
    private javax.swing.JButton btnCancelarCadastro;
    private javax.swing.JButton btnConfirmarCadastro;
    private javax.swing.JButton btnExcluirProduto;
    private javax.swing.JButton btnPesquisarProduto;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblConsultarMarca;
    private javax.swing.JLabel lblHD;
    private javax.swing.JLabel lblId;
    private javax.swing.JLabel lblIdProduto;
    private javax.swing.JLabel lblMarca;
    private javax.swing.JLabel lblProcessador;
    private javax.swing.JPanel pnlCadastrar;
    private javax.swing.JPanel pnlConsultar;
    private javax.swing.JTable tblProduto;
    private javax.swing.JTabbedPane telaProduto;
    private javax.swing.JTextField txtCampoConsultarMarca;
    private javax.swing.JTextField txtHD;
    private javax.swing.JTextField txtMarca;
    private javax.swing.JTextField txtProcessador;
    // End of variables declaration//GEN-END:variables
}
