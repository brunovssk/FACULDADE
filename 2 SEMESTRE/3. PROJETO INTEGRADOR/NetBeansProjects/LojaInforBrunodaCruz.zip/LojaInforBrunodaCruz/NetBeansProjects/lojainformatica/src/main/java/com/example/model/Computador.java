package com.example.model;

public class Computador {

    private int id;
    private String marca = "BrunoCruz";
    private String hd;
    private String processador;

    public Computador(String marca) {
        this.marca = marca;
        this.hd = hd;
        this.processador = processador;
    }

    // Getters e setters (se necessário)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getHd() {
        return hd;
    }

    public void setHd(String hd) {
        this.hd = hd;
    }

    public String getProcessador() {
        return processador;
    }

    public void setProcessador(String processador) {
        this.processador = processador;
    }
}
