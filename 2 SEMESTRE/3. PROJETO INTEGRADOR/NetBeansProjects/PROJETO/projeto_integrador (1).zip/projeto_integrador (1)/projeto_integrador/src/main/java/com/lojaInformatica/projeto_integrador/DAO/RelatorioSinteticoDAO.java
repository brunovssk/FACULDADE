package com.lojaInformatica.projeto_integrador.DAO;

import com.lojaInformatica.projeto_integrador.classes.RelatorioSintetico;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

public class RelatorioSinteticoDAO {

    // Conexão MySQL (possíveis alterações)
    private static final String URL = "jdbc:mysql://localhost:3306/pi_LojaInformatica"; // Altere conforme o nome da Loja MySQL
    private static final String LOGIN = "root"; // Inclua a informação do usuário (por exemplo, "kaio")
    private static final String SENHA = "080394"; // Inclua a informação da senha (por exemplo, "minhasenha")

    public static ArrayList<RelatorioSintetico> listarPorPeriodo(Date dataInicial, Date dataFinal) {
        Connection conexao = null;
        ResultSet rs = null;
        ArrayList<RelatorioSintetico> listaRetorno = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Certifique-se de que o driver MySQL está disponível
            conexao = DriverManager.getConnection(URL, LOGIN, SENHA);

            // Consulta SQL
            String sql = "SELECT Venda.idVenda, Venda.idCliente, Cliente.nome, Venda.dataVenda, Venda.valorVenda " +
                         "FROM Venda " +
                         "INNER JOIN Clientes ON Venda.idCliente = Clientes.idCliente " + // Corrigido o nome da tabela
                         "WHERE Venda.dataVenda BETWEEN ? AND ?";
            PreparedStatement comandoSQL = conexao.prepareStatement(sql);

            // Parâmetros para filtrar no SQL por data
            comandoSQL.setDate(1, new java.sql.Date(dataInicial.getTime()));
            comandoSQL.setDate(2, new java.sql.Date(dataFinal.getTime()));

            rs = comandoSQL.executeQuery();

            while (rs.next()) {
                int idVenda = rs.getInt("idVenda");
                int idCliente = rs.getInt("idCliente");
                String nomeCliente = rs.getString("nome");
                Date dataVenda = rs.getDate("dataVenda");
                double valorVenda = rs.getDouble("valorVenda");

                // Criação do objeto RelatorioSintetico e adição à lista de retorno
                RelatorioSintetico item = new RelatorioSintetico(idVenda, idCliente, nomeCliente, dataVenda, valorVenda);
                listaRetorno.add(item);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            listaRetorno = null;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (conexao != null) {
                    conexao.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return listaRetorno;
    }
}
