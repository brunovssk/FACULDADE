/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lojaInformatica.projeto_integrador.DAO;

import com.lojaInformatica.projeto_integrador.classes.Produto;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author skaio
 */
//-----------------------------CONEXAO DB--------------------------------------------
public class ProdutosDAO {

    static String URL = "jdbc:mysql://localhost:3306/pi_LojaInformatica";
    static String login = "root";
    static String senha = "080394";

    public static boolean salvar(Produto obj) {
        Connection conexao = null;

        boolean retorno = false;

        try {
            // 1- Carregando o driver mysql
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2- Fazendo a conexão: 
            conexao = DriverManager.getConnection(URL, login, senha);

//-----------------------------------FIM CONEXAO---------------------------------------
//----------------------------------Iniciando inserção no BD----------------------------
            // 3- Preparando o comando SQL
            PreparedStatement instrucaoSQL = conexao.prepareStatement(
                    "INSERT INTO Produtos (idProduto, referencia, descricao, descricaoReduzida, categoria, marca, numeroSerie, codigoFornecedor, fornecedor, quantidade, valorUnitario, dataInclusao, corVariacao, modelo, condicao, obs, motivo, validade, lote, dimensoesCm, pesoKg, garantia, dataInicio, dataFim, cobertura, contatoGarantia, obsGarantia) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");

            instrucaoSQL.setInt(1, obj.getIdProduto());
            instrucaoSQL.setString(2, obj.getReferencia());
            instrucaoSQL.setString(3, obj.getDescricao());
            instrucaoSQL.setString(4, obj.getDescricaoReduzida());
            instrucaoSQL.setInt(5, obj.getCategoria());
            instrucaoSQL.setInt(6, obj.getMarca());
            instrucaoSQL.setString(7, obj.getNumeroSerie());
            instrucaoSQL.setString(8, obj.getCodigoFornecedor());
            instrucaoSQL.setString(9, obj.getFornecedor());
            instrucaoSQL.setInt(10, obj.getQuantidade());
            instrucaoSQL.setDouble(11, obj.getValorUnitario());
            instrucaoSQL.setDate(12, new java.sql.Date(obj.getDataInclusao().getTime()));
            instrucaoSQL.setString(13, obj.getCorVariacao());
            instrucaoSQL.setString(14, obj.getModelo());
            instrucaoSQL.setInt(15, obj.getCondicao());
            instrucaoSQL.setString(16, obj.getObs());
            instrucaoSQL.setInt(17, obj.getMotivo());
            instrucaoSQL.setDate(18, new java.sql.Date(obj.getValidade().getTime()));
            instrucaoSQL.setInt(19, obj.getLote());
            instrucaoSQL.setDouble(20, obj.getDimensoesCm());
            instrucaoSQL.setDouble(21, obj.getPesoKg());
            instrucaoSQL.setInt(22, obj.getGarantia());
            instrucaoSQL.setDate(23, new java.sql.Date(obj.getDataInicio().getTime()));
            instrucaoSQL.setDate(24, new java.sql.Date(obj.getDataFim().getTime()));
            instrucaoSQL.setInt(25, obj.getCobertura());
            instrucaoSQL.setString(26, obj.getContatoGarantia());
            instrucaoSQL.setString(27, obj.getObsGarantia());

            //4- executar o comando:
            int linhasAfetadas = instrucaoSQL.executeUpdate();

            if (linhasAfetadas > 0) {
                retorno = true;
            }
        } catch (ClassNotFoundException e) {
            System.out.println("Driver não encontrado!");
        } catch (Exception e) {

            System.out.println(e.getMessage());
        } finally {

            if (conexao != null) {

                try {
                    conexao.close();
                } catch (SQLException ex) {
                    Logger.getLogger(ProdutosDAO.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

        return retorno;

    }
    // ----------------Fim da etapa de cadastro no DB-------------
    
    
    
    //------------------------INICIANDO A CONSULTA NO DB--------------------------
    
    // Criando um método para consultar no DB
    public static ArrayList<Produto> listar() {
        ArrayList<Produto> listaRetorno = new ArrayList<>();
        Connection conexao = null;
        ResultSet rs = null;

        try {
            // 1- Carregando o driver mysql
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2- Fazendo a conexão: 
            conexao = DriverManager.getConnection(URL, login, senha);

            // 3- Preparando o comando SQL
            PreparedStatement instrucaoSQL = conexao.prepareStatement(
                    "SELECT * FROM Produtos;");

            // 4- Executar o comando:
            rs = instrucaoSQL.executeQuery();
            if (rs != null) {

                while (rs.next()) {
//    public Produto(int IdProduto, String referencia, String descricao, String descricaoReduzida, int categoria, int marca, String numeroSerie, String codigoFornecedor, 
//String fornecedor, int quantidade, double valorUnitario, Date dataInclusao, String corVariacao, String modelo, int condicao, String obs, 
// int motivo, Date validade, int lote, double dimensoesCm, double pesoKg, int garantia, Date dataInicio, Date dataFim, int cobertura, String contatoGarantia, String obsGarantia) {

                    int idProduto = rs.getInt("idProduto");//
                    String referencia = rs.getString("referencia");
                    String descricao = rs.getString("descricao");//
                    String descricaoReduzida = rs.getString("descricaoReduzida");
                    int categoria = rs.getInt("categoria");
                    int marca = rs.getInt("marca");
                    String numeroSerie = rs.getString("numeroSerie");
                    String codigoFornecedor = rs.getString("codigoFornecedor");
                    String fornecedor = rs.getString("fornecedor");
                    int quantidade = rs.getInt("quantidade");
                    double valorUnitario = rs.getDouble("valorUnitario");//
                    Date dataInclusao = rs.getDate("dataInclusao");
                    String corVariacao = rs.getString("corVariacao");
                    String modelo = rs.getString("modelo");
                    int condicao = rs.getInt("condicao");
                    String obs = rs.getString("obs");
                    int motivo = rs.getInt("motivo");
                    Date validade = rs.getDate("validade");
                    int lote = rs.getInt("lote");//
                    double dimensoesCm = rs.getDouble("dimensoesCm");
                    double pesoKg = rs.getDouble("pesoKg");
                    int garantia = rs.getInt("garantia");
                    Date dataInicio = rs.getDate("dataInicio");
                    Date dataFim = rs.getDate("dataFim");
                    int cobertura = rs.getInt("cobertura");
                    String contatoGarantia = rs.getString("contatoGarantia");
                    String obsGarantia = rs.getString("obsGarantia");

                    Produto item = new Produto(idProduto, referencia, descricao, descricaoReduzida, categoria, marca, numeroSerie, codigoFornecedor, fornecedor, quantidade, valorUnitario, dataInclusao, corVariacao, modelo, condicao, obs, motivo, validade, lote, dimensoesCm, pesoKg, garantia, dataInicio, dataFim, cobertura, contatoGarantia, obsGarantia);
                    listaRetorno.add(item);

                }
            }

        } catch (Exception e) {
            listaRetorno = null;
        } finally {
            if (conexao != null) {
                try {
                    conexao.close();
                } catch (SQLException ex) {
                    Logger.getLogger(ProdutosDAO.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    Logger.getLogger(ProdutosDAO.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return listaRetorno;
    }

    public static boolean alterar(Produto obj) {
    Connection conexao = null;
    PreparedStatement instrucaoSQL = null;
    boolean retorno = false;

    try {
        // 1- Carregando o driver mysql
        Class.forName("com.mysql.cj.jdbc.Driver");

        // 2- Fazendo a conexão
        conexao = DriverManager.getConnection(URL, login, senha);

        // 3- Preparando o comando SQL
        String sql = "UPDATE Produtos SET referencia=?, descricao=?, descricaoReduzida=?, categoria=?, marca=?, " +
                     "numeroSerie=?, codigoFornecedor=?, fornecedor=?, quantidade=?, valorUnitario=?, dataInclusao=?, " +
                     "corVariacao=?, modelo=?, condicao=?, obs=?, motivo=?, validade=?, lote=?, dimensoesCm=?, pesoKg=?, " +
                     "garantia=?, dataInicio=?, dataFim=?, cobertura=?, contatoGarantia=?, obsGarantia=? WHERE idProduto=?";
        instrucaoSQL = conexao.prepareStatement(sql);

        // Definindo os parâmetros
        instrucaoSQL.setString(1, obj.getReferencia());
        instrucaoSQL.setString(2, obj.getDescricao());
        instrucaoSQL.setString(3, obj.getDescricaoReduzida());
        instrucaoSQL.setInt(4, obj.getCategoria());
        instrucaoSQL.setInt(5, obj.getMarca());
        instrucaoSQL.setString(6, obj.getNumeroSerie());
        instrucaoSQL.setString(7, obj.getCodigoFornecedor());
        instrucaoSQL.setString(8, obj.getFornecedor());
        instrucaoSQL.setInt(9, obj.getQuantidade());
        instrucaoSQL.setDouble(10, obj.getValorUnitario());
        instrucaoSQL.setDate(11, obj.getDataInclusao() != null ? new java.sql.Date(obj.getDataInclusao().getTime()) : null);
        instrucaoSQL.setString(12, obj.getCorVariacao());
        instrucaoSQL.setString(13, obj.getModelo());
        instrucaoSQL.setInt(14, obj.getCondicao());
        instrucaoSQL.setString(15, obj.getObs());
        instrucaoSQL.setInt(16, obj.getMotivo());
        instrucaoSQL.setDate(17, obj.getValidade() != null ? new java.sql.Date(obj.getValidade().getTime()) : null);
        instrucaoSQL.setInt(18, obj.getLote());
        instrucaoSQL.setDouble(19, obj.getDimensoesCm());
        instrucaoSQL.setDouble(20, obj.getPesoKg());
        instrucaoSQL.setInt(21, obj.getGarantia());
        instrucaoSQL.setDate(22, obj.getDataInicio() != null ? new java.sql.Date(obj.getDataInicio().getTime()) : null);
        instrucaoSQL.setDate(23, obj.getDataFim() != null ? new java.sql.Date(obj.getDataFim().getTime()) : null);
        instrucaoSQL.setInt(24, obj.getCobertura());
        instrucaoSQL.setString(25, obj.getContatoGarantia());
        instrucaoSQL.setString(26, obj.getObsGarantia());
        instrucaoSQL.setInt(27, obj.getIdProduto());

        // 4- Executar o comando
        int linhasAfetadas = instrucaoSQL.executeUpdate();

        if (linhasAfetadas > 0) {
            retorno = true;
        }
    } catch (ClassNotFoundException e) {
        System.out.println("Driver não encontrado: " + e.getMessage());
    } catch (SQLException e) {
        System.out.println("Erro de SQL: " + e.getMessage());
    } finally {
        try {
            if (instrucaoSQL != null) instrucaoSQL.close();
            if (conexao != null) conexao.close();
        } catch (SQLException ex) {
            Logger.getLogger(ProdutosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    return retorno;
}

    // Iniciando o método para excluir do DB 
    public static boolean excluir(int idExcluir) {
        Connection conexao = null;

        boolean retorno = false;

        try {
            // 1- Carregando o driver mysql
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2- Fazendo a conexão: 
            conexao = DriverManager.getConnection(URL, login, senha);

            // 3- Preparando o comando SQL
            PreparedStatement instrucaoSQL = conexao.prepareStatement(
                    "DELETE FROM Produtos WHERE idProduto = ?;");

//            instrucaoSQL.setString(2, obj.getReferencia());
//            instrucaoSQL.setString(3, obj.getDescricao());
//            instrucaoSQL.setString(4, obj.getDescricaoReduzida());
//            instrucaoSQL.setInt(5, obj.getCategoria());
//            instrucaoSQL.setInt(6, obj.getMarca());
//            instrucaoSQL.setString(7, obj.getNumeroSerie());
//            instrucaoSQL.setString(8, obj.getCodigoFornecedor());
//            instrucaoSQL.setString(9, obj.getFornecedor());
//            instrucaoSQL.setInt(10, obj.getQuantidade());
//            instrucaoSQL.setDouble(11, obj.getValorUnitario());
//            instrucaoSQL.setDate(12, new java.sql.Date(obj.getDataInclusao().getTime()));
//            instrucaoSQL.setString(13, obj.getCorVariacao());
//            instrucaoSQL.setString(14, obj.getModelo());
//            instrucaoSQL.setInt(15, obj.getCondicao());
//            instrucaoSQL.setString(16, obj.getObs());
//            instrucaoSQL.setInt(17, obj.getMotivo());
//            instrucaoSQL.setDate(18, new java.sql.Date(obj.getValidade().getTime()));
//            instrucaoSQL.setInt(19, obj.getLote());
//            instrucaoSQL.setDouble(20, obj.getDimensoesCm());
//            instrucaoSQL.setDouble(21, obj.getPesoKg());
//            instrucaoSQL.setInt(22, obj.getGarantia());
//            instrucaoSQL.setDate(23, new java.sql.Date(obj.getDataInicio().getTime()));
//            instrucaoSQL.setDate(24, new java.sql.Date(obj.getDataFim().getTime()));
//            instrucaoSQL.setInt(25, obj.getCobertura());
//            instrucaoSQL.setString(26, obj.getContatoGarantia());
//            instrucaoSQL.setString(27, obj.getObsGarantia());
            instrucaoSQL.setInt(1, idExcluir);

            //4- executar o comando:
            int linhasAfetadas = instrucaoSQL.executeUpdate();

            if (linhasAfetadas > 0) {
                retorno = true;
            }
        } catch (ClassNotFoundException e) {
            System.out.println("Driver não encontrado!");
        } catch (Exception e) {

            System.out.println(e.getMessage());
        } finally {

            if (conexao != null) {

                try {
                    conexao.close();
                } catch (SQLException ex) {
                    Logger.getLogger(ProdutosDAO.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

        return retorno;

    }
}
