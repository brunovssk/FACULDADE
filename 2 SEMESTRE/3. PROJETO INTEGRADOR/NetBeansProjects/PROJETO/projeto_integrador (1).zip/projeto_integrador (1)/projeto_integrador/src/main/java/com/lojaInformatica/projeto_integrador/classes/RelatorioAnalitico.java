package com.lojaInformatica.projeto_integrador.classes;

/**
 * Classe que representa um relatório analítico.
 */
public class RelatorioAnalitico {

    private int idVenda; // Adicionado o campo idVenda
    private int qtdProduto;
    private String codigoProduto;
    private String nomeProduto;
    private String formaPagamento;
    private String fornecedor;
    private String modelo;
    private double vlrUnitario; // Alterado para double para representar valores decimais

    // Construtor
    public RelatorioAnalitico(int idVenda, int qtdProduto, String codigoProduto, double vlrUnitario, int qtdProduto1, String nomeProduto, String formaPagamento) {
        this.idVenda = idVenda;
        this.qtdProduto = qtdProduto;
        this.codigoProduto = codigoProduto;
        this.nomeProduto = nomeProduto;
        this.formaPagamento = formaPagamento;
        this.fornecedor = fornecedor;
        this.modelo = modelo;
        this.vlrUnitario = vlrUnitario;
    }

    // Getters
    public int getIdVenda() {
        return idVenda;
    }

    public int getQtdProduto() {
        return qtdProduto;
    }

    public String getCodigoProduto() {
        return codigoProduto;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public String getModelo() {
        return modelo;
    }

    public double getVlrUnitario() {
        return vlrUnitario;
    }

    // Setters
    public void setIdVenda(int idVenda) {
        this.idVenda = idVenda;
    }

    public void setQtdProduto(int qtdProduto) {
        this.qtdProduto = qtdProduto;
    }

    public void setCodigoProduto(String codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setVlrUnitario(double vlrUnitario) {
        this.vlrUnitario = vlrUnitario;
    }
}
