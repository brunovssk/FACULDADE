/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lojaInformatica.projeto_integrador.DAO;

import com.lojaInformatica.projeto_integrador.classes.Clientes;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ClientesDAO {

    static String URL = "jdbc:mysql://localhost:3306/pi_LojaInformatica";
    static String login = "root";
    static String senha = "080394";

    public static boolean salvar(Clientes obj) {
        Connection conexao = null;
        boolean retorno = false;

        try {
            // 1- Carregando o driver MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2- Fazendo a conexão
            conexao = DriverManager.getConnection(URL, login, senha);

            // 3- Preparando o comando SQL
            PreparedStatement instrucaoSQL = conexao.prepareStatement(
                    "INSERT INTO Clientes (idCliente, nome, sobrenome, cpf, dataNascimento, email, cep, numero, telefone, estadoCivil, genero) VALUES (?,?,?,?,?,?,?,?,?,?,?);");
//    public Clientes(int idCliente, String nome, String sobrenome, String email, int cep, String cpf, String telefone, Date jcdNscimento) {
            instrucaoSQL.setInt(1, obj.getIdCliente());
            instrucaoSQL.setString(2, obj.getNome());
            instrucaoSQL.setString(3, obj.getSobrenome());
               instrucaoSQL.setString(4, obj.getCpf());
                 instrucaoSQL.setDate(5, new java.sql.Date(obj.getDataNascimento().getTime()));
            instrucaoSQL.setString(6, obj.getEmail());
            instrucaoSQL.setInt(7, obj.getCep());
         instrucaoSQL.setInt(8, obj.getNumero());
            instrucaoSQL.setString(9, obj.getTelefone());
             instrucaoSQL.setInt(10, obj.getEstadoCivil());
             instrucaoSQL.setInt(11, obj.getGenero());
            
   
            // 4- Executando o comando
            int linhasAfetadas = instrucaoSQL.executeUpdate();

            if (linhasAfetadas > 0) {
                retorno = true;
            }
        } catch (ClassNotFoundException e) {
            System.out.println("Driver não encontrado!");
        } catch (SQLException e) {
            System.out.println("Erro ao executar SQL: " + e.getMessage());
        } finally {
            if (conexao != null) {
                try {
                    conexao.close();
                } catch (SQLException ex) {
                    Logger.getLogger(ClientesDAO.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

        return retorno;
    }
}
    

