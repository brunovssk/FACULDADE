package com.lojaInformatica.projeto_integrador.classes;

import java.util.Date;

/**
 * OBS sujeito a alteração conforme BANCO DE DADOS e Tela de vendas =BRUNO=
 * Autor: giovanna.sramos3
 */
public class RelatorioSintetico {
    
    private int idVenda; //<----Sujeito a alteração
    private int idCliente; //<----Sujeito a troca
    private String nomeCliente; //<----Sujeito a troca
    private Date dataVenda; //<----Alterado para Date conforme o banco de dados
    private double valorVenda; //<----Adicionado campo valorVenda
    
    // Construtor padrão
    public RelatorioSintetico(int idVenda1, int idCliente1, String nomeCliente1, Date dataVenda1, double valorVenda1) {
    }

    // Construtor parametrizado
    public RelatorioSintetico(int idVenda, int idCliente, String nomeCliente, Date dataVenda, float valorVenda) {
        this.idVenda = idVenda;
        this.idCliente = idCliente;
        this.nomeCliente = nomeCliente;
        this.dataVenda = dataVenda;
        this.valorVenda = valorVenda;
    }

    // Getters and Setters
    public int getIdVenda() {
        return idVenda;
    }

    public void setIdVenda(int idVenda) {
        this.idVenda = idVenda;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public Date getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(Date dataVenda) {
        this.dataVenda = dataVenda;
    }

    public double getValorVenda() {
        return valorVenda;
    }

    public void setValorVenda(float valorVenda) {
        this.valorVenda = valorVenda;
    }

    public Object getDataInicial() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Object getDataFinal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
