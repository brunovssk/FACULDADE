package com.lojaInformatica.projeto_integrador.classes;

import java.util.Date;

public class Produto {

    private int idProduto;
    private String referencia;
    private String descricao;
    private String descricaoReduzida;
    private int categoria;
    private int marca;
    private String numeroSerie;
    private String codigoFornecedor;
    private String fornecedor;
    private int quantidade;
    private double valorUnitario;
    private Date dataInclusao;
    private String corVariacao;
    private String modelo;
    private int condicao;
    private String obs;
    private int motivo;
    private Date validade;
    private int lote;
    private double dimensoesCm;
    private double pesoKg;
    private int garantia;
    private Date dataInicio;
    private Date dataFim;
    private int cobertura;
    private String contatoGarantia;
    private String obsGarantia;

    public Produto(int idProduto, String descricao, double valorUnitario, int lote) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getIdProduto() {
        return idProduto;
    }

    public void setIdProduto(int IdProduto) {
        this.idProduto = IdProduto;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricaoReduzida() {
        return descricaoReduzida;
    }

    public void setDescricaoReduzida(String descricaoReduzida) {
        this.descricaoReduzida = descricaoReduzida;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public int getMarca() {
        return marca;
    }

    public void setMarca(int marca) {
        this.marca = marca;
    }

    public String getNumeroSerie() {
        return numeroSerie;
    }

    public void setNumeroSerie(String numeroSerie) {
        this.numeroSerie = numeroSerie;
    }

    public String getCodigoFornecedor() {
        return codigoFornecedor;
    }

    public void setCodigoFornecedor(String codigoFornecedor) {
        this.codigoFornecedor = codigoFornecedor;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getValorUnitario() {
        return valorUnitario;
    }

    public void setValorUnitario(double valorUnitario) {
        this.valorUnitario = valorUnitario;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    public String getCorVariacao() {
        return corVariacao;
    }

    public void setCorVariacao(String corVariacao) {
        this.corVariacao = corVariacao;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getCondicao() {
        return condicao;
    }

    public void setCondicao(int condicao) {
        this.condicao = condicao;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public int getMotivo() {
        return motivo;
    }

    public void setMotivo(int motivo) {
        this.motivo = motivo;
    }

    public Date getValidade() {
        return validade;
    }

    public void setValidade(Date validade) {
        this.validade = validade;
    }

    public int getLote() {
        return lote;
    }

    public void setLote(int lote) {
        this.lote = lote;
    }

    public double getDimensoesCm() {
        return dimensoesCm;
    }

    public void setDimensoesCm(double dimensoesCm) {
        this.dimensoesCm = dimensoesCm;
    }

    public double getPesoKg() {
        return pesoKg;
    }

    public void setPesoKg(double pesoKg) {
        this.pesoKg = pesoKg;
    }

    public int getGarantia() {
        return garantia;
    }

    public void setGarantia(int garantia) {
        this.garantia = garantia;
    }

    public Date getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(Date dataInicio) {
        this.dataInicio = dataInicio;
    }

    public Date getDataFim() {
        return dataFim;
    }

    public void setDataFim(Date dataFim) {
        this.dataFim = dataFim;
    }

    public int getCobertura() {
        return cobertura;
    }

    public void setCobertura(int cobertura) {
        this.cobertura = cobertura;
    }

    public String getContatoGarantia() {
        return contatoGarantia;
    }

    public void setContatoGarantia(String contatoGarantia) {
        this.contatoGarantia = contatoGarantia;
    }

    public String getObsGarantia() {
        return obsGarantia;
    }

    public void setObsGarantia(String obsGarantia) {
        this.obsGarantia = obsGarantia;
    }


    // Construtores:

    public Produto(int idProduto, String referencia, String descricao, String descricaoReduzida, int categoria, int marca, String numeroSerie, String codigoFornecedor, String fornecedor, int quantidade, double valorUnitario, Date dataInclusao, String corVariacao, String modelo, int condicao, String obs, int motivo, Date validade, int lote, double dimensoesCm, double pesoKg, int garantia, Date dataInicio, Date dataFim, int cobertura, String contatoGarantia, String obsGarantia) {
        this.idProduto = idProduto;
        this.referencia = referencia;
        this.descricao = descricao;
        this.descricaoReduzida = descricaoReduzida;
        this.categoria = categoria;
        this.marca = marca;
        this.numeroSerie = numeroSerie;
        this.codigoFornecedor = codigoFornecedor;
        this.fornecedor = fornecedor;
        this.quantidade = quantidade;
        this.valorUnitario = valorUnitario;
        this.dataInclusao = dataInclusao;
        this.corVariacao = corVariacao;
        this.modelo = modelo;
        this.condicao = condicao;
        this.obs = obs;
        this.motivo = motivo;
        this.validade = validade;
        this.lote = lote;
        this.dimensoesCm = dimensoesCm;
        this.pesoKg = pesoKg;
        this.garantia = garantia;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.cobertura = cobertura;
        this.contatoGarantia = contatoGarantia;
        this.obsGarantia = obsGarantia;
    }
    
    


    }

 
    

 
        
        
        
        
        
    
    
    
    
    
    

    


