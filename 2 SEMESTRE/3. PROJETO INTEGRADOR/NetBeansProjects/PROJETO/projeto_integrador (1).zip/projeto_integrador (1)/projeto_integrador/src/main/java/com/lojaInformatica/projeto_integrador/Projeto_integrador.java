/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.lojaInformatica.projeto_integrador;

/**
 *
 * @author Giovanna
 */
public class Projeto_integrador {

    public static void main(String[] args) {
        TelaLogin telaLogin = new TelaLogin();
        telaLogin.setLocationRelativeTo(null);
        telaLogin.setVisible(true);

        
    }
}
