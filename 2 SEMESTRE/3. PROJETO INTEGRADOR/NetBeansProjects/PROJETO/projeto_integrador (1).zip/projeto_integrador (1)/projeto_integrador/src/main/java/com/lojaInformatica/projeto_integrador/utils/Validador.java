/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lojaInformatica.projeto_integrador.utils;

import java.awt.Color;

import static java.awt.SystemColor.text;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Validador {

    public ArrayList<String> mensagensErro = new ArrayList<>();

    public static void validarTexto(JTextField objValidar) {

        try {
            if (objValidar.getText().strip().equalsIgnoreCase("")) {
                throw new Exception();
            }
        } catch (Exception e) {
            objValidar.setBackground(Color.white);

        }
    }

    public void ValidarNumero(JTextField txt) {

        try {

            if (txt.getText().trim().equals("")) {
                throw new IllegalArgumentException();
            }

            int valorConvertido = Integer.parseInt(txt.getText());
            txt.setBackground(Color.WHITE);

        } catch (NumberFormatException e) {

            this.mensagensErro.add("Falha ao converter o valor do campo " + txt.getName() + " em inteiro");
            txt.setBackground(Color.red);
        } catch (IllegalArgumentException e) {
            this.mensagensErro.add("Digite um valor para o campo " + txt.getName());
            txt.setBackground(Color.red);
        }

    }

    public void ValidarFloat(JTextField txt) {

        try {

            //Verifico se o campo está vazio
            if (txt.getText().trim().equals("")) {
                throw new IllegalArgumentException();
            }

            float valorConvertido = Float.parseFloat(txt.getText());
            txt.setBackground(Color.WHITE);

        } catch (NumberFormatException e) {

            this.mensagensErro.add("Falha ao converter o valor do campo " + txt.getName() + " em float");
            txt.setBackground(Color.red);
        } catch (IllegalArgumentException e) {
            this.mensagensErro.add("Digite um valor para o campo " + txt.getName());
            txt.setBackground(Color.red);
        }

    }

    public void limparMensagens() {

        this.mensagensErro.clear();
    }

    /**
     * @deprecated substituida por {@link #getMensagensErro()} Método para
     * exibir mensagens de erro na tela com JOptionPane
     */
    public void ExibirMensagensErro() {

        String errosFormulario = "";
        for (String msg : this.mensagensErro) {
            errosFormulario += msg + "\n";
        }

        if (!errosFormulario.equals("")) {
            JOptionPane.showMessageDialog(null, errosFormulario);
            this.limparMensagens();
        }

    }

    /**
     * Resgata todos os erros gerados em uma única String
     *
     * @return
     */
    public String getMensagensErro() {

        String errosFormulario = "";

        //Percorro o arrayList e concateno na variável errosFormulario
        for (String msg : this.mensagensErro) {
            errosFormulario += msg + "\n";
        }

        if (!errosFormulario.equals("")) {
            this.limparMensagens();
        }

        return errosFormulario;

    }

    public boolean hasErro() {

        if (this.mensagensErro.size() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean ValidarUsuario(String usuario, String senha) {
        if (usuario.equals("admin") && senha.equals("admin")) {
            return true;
        } else {
            return false;
        }
    }
    // adicionar validador da tela de clienteCRUD
    
    
    
    
    
    //Validador da tela de produtos
public class ValidadorProdutos {

    public static List<String> validarCampos(JTextField... campos) {
        List<String> mensagensErro = new ArrayList<>();

        for (JTextField campo : campos) {
            if (campo.getText().trim().isEmpty()) {
                mensagensErro.add("O campo " + campo.getName() + " está vazio.");
            }
        }

        return mensagensErro;
    }}}




        

