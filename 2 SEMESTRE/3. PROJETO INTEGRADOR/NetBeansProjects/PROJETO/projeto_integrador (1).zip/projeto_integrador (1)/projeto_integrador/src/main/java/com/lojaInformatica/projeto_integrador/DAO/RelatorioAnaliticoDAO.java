package com.lojaInformatica.projeto_integrador.DAO;

import com.lojaInformatica.projeto_integrador.classes.RelatorioAnalitico;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class RelatorioAnaliticoDAO {
    
    // Conexão MySQL (possíveis alterações)
    static String URL = "jdbc:mysql://localhost:3306/pi_LojaInformatica";
    static String login = "root";
    static String senha = "080394";
    
    public static ArrayList<RelatorioAnalitico> listarPorVenda(int idVenda) {
        Connection conexao = null;
        ResultSet rs = null;
        ArrayList<RelatorioAnalitico> listaRetorno = new ArrayList<>();
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Certifique-se de que o driver MySQL está disponível
            conexao = DriverManager.getConnection(URL, login, senha);
            
            // Consulta SQL para buscar os detalhes do relatório analítico por venda
            String sql = "SELECT Venda.idVenda, ItemVenda.idProduto, Produto.descricao, ItemVenda.vlrUnitario, " +
                         "ItemVenda.qtdProduto, Venda.modelo, Venda.fornecedor " +
                         "FROM ItemVenda " +
                         "INNER JOIN Produto ON ItemVenda.idProduto = Produto.idProduto " +
                         "INNER JOIN Venda ON ItemVenda.idVenda = Venda.idVenda " +
                         "WHERE ItemVenda.idVenda = ?";
            PreparedStatement comandoSQL = conexao.prepareStatement(sql);
            
            // Parâmetros para filtrar no SQL por idVenda
            comandoSQL.setInt(1, idVenda);

            rs = comandoSQL.executeQuery();
            
            while (rs.next()) {
                int idVendaRetornado = rs.getInt("idVenda");
                int idProduto = rs.getInt("idProduto");
                String descricaoProduto = rs.getString("descricao");
                double valorUnitario = rs.getFloat("vlrUnitario");
                int qtdProduto = rs.getInt("qtdProduto");
                String modelo = rs.getString("modelo");
                String fornecedor = rs.getString("fornecedor");
                                        
                // Criação do objeto RelatorioAnalitico e adição à lista de retorno
                RelatorioAnalitico item = new RelatorioAnalitico(idVendaRetornado, idProduto, descricaoProduto, valorUnitario, qtdProduto, modelo, fornecedor);
                listaRetorno.add(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
            listaRetorno = null;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (conexao != null) {
                    conexao.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        return listaRetorno;
    }
}
